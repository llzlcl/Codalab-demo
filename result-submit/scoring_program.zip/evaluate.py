import sys
import os
from os.path import join
import csv
import numpy as np 

input_dir = sys.argv[1]
output_dir = sys.argv[2]

reference=[]
auc=[]
result_path=join(input_dir,'res')
reference_path=join(input_dir,'ref')
output_filename = join(output_dir, 'scores.txt')

def get_ref(ref_path):
    refe=[]
    with open(ref_path, 'r') as ref:
        r=csv.reader(ref)
        r.__next__()
        for i in range(3517):
            refe.append(int(r.__next__()[2]))
    return(refe)

def get_auc(ref,res):
    count=0.0
    for i in range(len(ref)):
        if ref[i]==res[i]:
            count=count+1
    return count/len(ref)

def get_score(result_path):
    result_file=open(result_path,'r')
    r=csv.reader(result_file)
    r.__next__()
    result=[]
    for i in range(3517):
        result.append(int(r.__next__()[2]))
    #print(reference)
    auc.append(get_auc(reference,result))
    result_file.close()

for i in range(1,10):
    ref_path=join(reference_path,'label'+str(i)+'.csv')
    res_path=join(result_path,'test_batch'+str(i)+'.csv')
    reference=get_ref(ref_path)
    get_score(res_path)

with open(output_filename, 'w') as score_file:    
    score_file.write('result: '+str(np.mean(auc))+'\n')
    

